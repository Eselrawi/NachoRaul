package com.example.editortextogui;

import com.example.editortextogui.NuiCommand;
import com.example.editortextogui.NuiController;
import com.example.editortextogui.NuiListener;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.function.UnaryOperator;

public class EditorController implements NuiListener {

    @FXML private TextArea textArea;
    @FXML private Label lblStatus;
    @FXML private ProgressBar progressBar;
    @FXML private TextField txtVoz;

    @FXML private MenuItem miMayusculas;
    @FXML private MenuItem miInvertir;
    @FXML private MenuItem miRemoveSpaces;
    @FXML private MenuItem miApplyPipeline;
    @FXML private MenuItem miDeshacer;

    private final List<UnaryOperator<String>> pipeline = new ArrayList<>();
    private final NuiController nuiController = new NuiController();

    // --- Mini-historial de cambios para deshacer ---
    private final Stack<String> undoStack = new Stack<>();
    private final int MAX_UNDO = 50; // limitar historial

    @FXML
    public void initialize() {
        nuiController.addNuiListener(this);

        // Contadores automáticos y guardado de historial
        textArea.textProperty().addListener((obs, oldVal, newVal) -> {
            updateStats(newVal);
            if (!oldVal.equals(newVal)) pushUndo(oldVal); // Guardar en historial para deshacer
        });

        // Menú contextual
        ContextMenu menu = new ContextMenu();
        MenuItem cut = new MenuItem("Cortar"); cut.setOnAction(e -> textArea.cut());
        MenuItem copy = new MenuItem("Copiar"); copy.setOnAction(e -> textArea.copy());
        MenuItem paste = new MenuItem("Pegar"); paste.setOnAction(e -> textArea.paste());
        menu.getItems().addAll(cut, copy, paste);
        textArea.setContextMenu(menu);

        // Atajos teclado
        textArea.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if(e.isControlDown() && e.getCode()== KeyCode.F){ e.consume(); showBuscarDialog(); }
            if(e.isControlDown() && e.getCode()== KeyCode.H){ e.consume(); showReemplazarDialog(); }
            if(e.isControlDown() && e.getCode()== KeyCode.Z){ e.consume(); deshacer(); }
        });

        // Mensajes de ayuda en lblStatus
        miMayusculas.setOnMenuValidation(e -> lblStatus.setText("Este botón pasará a mayúsculas todo el texto"));
        miInvertir.setOnMenuValidation(e -> lblStatus.setText("Este botón invertirá el texto seleccionado o todo el texto"));
        miRemoveSpaces.setOnMenuValidation(e -> lblStatus.setText("Este botón eliminará espacios dobles en el texto"));
        miApplyPipeline.setOnMenuValidation(e -> lblStatus.setText("Este botón aplicará todas las operaciones encadenadas"));
        miDeshacer.setOnMenuValidation(e -> lblStatus.setText("Revierte el último cambio realizado"));

        miMayusculas.getParentMenu().setOnHidden(e -> updateStats(textArea.getText()));

        // Mostrar tutorial actualizado al iniciar
        mostrarTutorial();
    }

    // -------------------- MÉTODOS NUEVOS --------------------
    private void pushUndo(String text) {
        if (undoStack.size() >= MAX_UNDO) undoStack.remove(0);
        undoStack.push(text);
    }

    @FXML
    private void deshacer() {
        if (!undoStack.isEmpty()) {
            String previous = undoStack.pop();
            textArea.setText(previous);
        } else {
            showAlert("No hay más cambios para deshacer.");
        }
    }

    private void mostrarTutorial() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Tutorial rápido");
        alert.setHeaderText("Bienvenido al Editor de Texto");
        alert.setContentText("""
                Bienvenido al editor. Estas son las mejoras implementadas:

                1. Deshacer cambios:
                   - Pulsa Ctrl+Z o usa el botón 'Deshacer' para revertir el último cambio.

                2. Copiar, Cortar y Pegar:
                   - Haz clic derecho sobre el área de texto para usar copiar, cortar o pegar.

                3. Mini-historial:
                   - Cada cambio que haces se guarda automáticamente para poder deshacerlo.

                Disfruta usando el editor!
                """);
        alert.showAndWait();
    }

    // -------------------- MÉTODOS EXISTENTES --------------------
    @FXML
    private void procesarVoz() {
        String texto = txtVoz.getText();
        if (texto != null && !texto.isEmpty()) {
            nuiController.procesarEntrada(texto);
            txtVoz.clear();
        }
    }

    @Override
    public void onCommand(NuiCommand cmd, String payload) {
        lblStatus.setText("Comando NUI: " + cmd);

        switch (cmd) {
            case NUEVO_DOCUMENTO -> {
                textArea.clear();
                updateStats("");
                showAlert("Nuevo documento creado.");
            }
            case ABRIR_DOCUMENTO -> abrir();
            case GUARDAR_DOCUMENTO -> guardar();
            case APLICAR_NEGRITA -> textArea.setStyle("-fx-font-weight: bold;");
            case APLICAR_CURSIVA -> textArea.setStyle("-fx-font-style: italic;");
            case COLOR_ROJO -> textArea.setStyle("-fx-text-fill: red;");
            case COLOR_AZUL -> textArea.setStyle("-fx-text-fill: blue;");
        }
    }

    private void updateStats(String s){
        int chars = s.length();
        int lines = s.isEmpty() ? 0 : (int)s.chars().filter(c->c=='\n').count()+1;
        int words = s.isBlank() ? 0 : s.trim().split("\\s+").length;
        lblStatus.setText(String.format("Chars:%d | Palabras:%d | Líneas:%d", chars, words, lines));
    }

    // ----------------- BUSCAR -----------------
    private void showBuscarDialog(){
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Buscar");
        dialog.setHeaderText("Buscar palabra o frase");
        dialog.setContentText("Término:");
        dialog.showAndWait().ifPresent(this::buscar);
    }

    private void buscar(String term){
        if(term==null || term.isEmpty()) return;
        String text = textArea.getText();
        int from = textArea.getCaretPosition();
        int pos = text.indexOf(term, from);
        if(pos<0) pos=text.indexOf(term);
        if(pos>=0){
            textArea.selectRange(pos, pos+term.length());
            textArea.requestFocus();
        } else showAlert("No encontrado");
    }

    // ----------------- REEMPLAZAR -----------------
    private void showReemplazarDialog(){
        TextInputDialog d1 = new TextInputDialog();
        d1.setTitle("Reemplazar");
        d1.setHeaderText("Palabra a buscar:");
        d1.setContentText("Buscar:");
        d1.showAndWait().ifPresent(oldW -> {
            TextInputDialog d2 = new TextInputDialog();
            d2.setTitle("Reemplazar");
            d2.setHeaderText("Reemplazar con:");
            d2.setContentText("Nuevo texto:");
            d2.showAndWait().ifPresent(newW -> reemplazarPrimero(oldW,newW));
        });
    }

    private void reemplazarPrimero(String term, String repl){
        String t=textArea.getText();
        int p=t.indexOf(term);
        if(p>=0) textArea.replaceText(p,p+term.length(),repl);
        else showAlert("No se encontró la palabra");
    }

    private void showAlert(String msg){
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        alert.showAndWait();
    }

    @FXML
    private void toUpper() {
        textArea.setText(TextUtils.toUpper(textArea.getText()));
        pipeline.add(TextUtils::toUpper);
    }

    @FXML
    private void invert() {
        textArea.setText(TextUtils.invert(textArea.getText()));
        pipeline.add(TextUtils::invert);
    }

    @FXML
    private void removeSpaces() {
        textArea.setText(TextUtils.removeDoubleSpaces(textArea.getText()));
        pipeline.add(TextUtils::removeDoubleSpaces);
    }

    @FXML
    private void applyPipeline() {
        String result = textArea.getText();
        for(var op : pipeline) result = op.apply(result);
        textArea.setText(result);
        pipeline.clear();
    }

    @FXML
    private void guardar() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Guardar archivo");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivo de texto (*.txt)", "*.txt"));

        var file = chooser.showSaveDialog(null);
        if (file == null) return;

        progressBar.setVisible(true);
        progressBar.setProgress(0);

        javafx.concurrent.Task<Void> task = new javafx.concurrent.Task<>() {
            @Override
            protected Void call() throws Exception {
                for (int i = 1; i <= 10; i++) {
                    Thread.sleep(70);
                    updateProgress(i, 10);
                }
                try (FileWriter writer = new FileWriter(file)) {
                    writer.write(textArea.getText());
                }
                return null;
            }
        };

        task.setOnSucceeded(e -> {
            progressBar.setVisible(false);
            showAlert("Archivo guardado correctamente.");
        });

        task.setOnFailed(e -> {
            progressBar.setVisible(false);
            showAlert("Error al guardar el archivo.");
        });

        progressBar.progressProperty().bind(task.progressProperty());
        new Thread(task).start();
    }

    @FXML
    private void abrir() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Abrir archivo");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivo de texto (*.txt)", "*.txt"));

        File file = chooser.showOpenDialog(null);
        if (file == null) return;

        try {
            String contenido = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            textArea.setText(contenido);
            showAlert("Archivo cargado correctamente.");
            actualizarContadores();
        } catch (Exception e) {
            showAlert("Error al abrir el archivo.");
        }
    }

    private void actualizarContadores() {
        String texto = textArea.getText();
        int chars = texto.length();
        int palabras = texto.isBlank() ? 0 : texto.trim().split("\\s+").length;
        int lineas = texto.split("\n", -1).length;
        lblStatus.setText("Chars:" + chars + " | Palabras:" + palabras + " | Líneas:" + lineas);
    }

    // ----------------- MÉTODOS PARA MENÚ CONTEXTUAL -----------------
    @FXML
    private void copy() { textArea.copy(); }
    @FXML
    private void cut() { textArea.cut(); }
    @FXML
    private void paste() { textArea.paste(); }

}
