package com.example.editortextogui;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.HBox;

/**
 * Componente reutilizable que mezcla Label + ProgressBar.
 * Tiene estados: idle, working, done, error.
 */
public class ProgresLabel extends HBox {

    public enum State { IDLE, WORKING, DONE, ERROR }

    private final Label lblText = new Label("Listo");
    private final ProgressBar bar = new ProgressBar(0);

    private State currentState = State.IDLE;

    public ProgresLabel() {
        setSpacing(10);
        setAlignment(Pos.CENTER_LEFT);

        bar.setPrefWidth(150);
        bar.setVisible(false);

        getChildren().addAll(lblText, bar);
        updateVisualState();
    }

    public void setState(State s){
        currentState = s;
        updateVisualState();
    }

    public void setProgress(double p){
        bar.setProgress(p);
    }

    public void setMessage(String msg){
        lblText.setText(msg);
    }

    public void reset(){
        setState(State.IDLE);
        bar.setProgress(0);
        setMessage("Listo");
    }

    private void updateVisualState() {
        switch (currentState){
            case IDLE -> {
                bar.setVisible(false);
                lblText.setStyle("-fx-text-fill: black;");
            }
            case WORKING -> {
                bar.setVisible(true);
                lblText.setStyle("-fx-text-fill: blue;");
            }
            case DONE -> {
                bar.setVisible(false);
                lblText.setStyle("-fx-text-fill: green;");
            }
            case ERROR -> {
                bar.setVisible(false);
                lblText.setStyle("-fx-text-fill: red;");
            }
        }
    }
}
