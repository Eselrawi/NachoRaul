package com.example.editortextogui;

public interface NuiListener {
    void onCommand(NuiCommand cmd, String payload);
}

