package com.example.editortextogui;

import java.util.ArrayList;
import java.util.List;

public class NuiController {
    private final List<NuiListener> listeners = new ArrayList<>();

    public void addNuiListener(NuiListener listener) {
        listeners.add(listener);
    }

    public void procesarEntrada(String entrada) {
        if (entrada == null) return;

        // 1. Convertimos a minúsculas para ignorar Mayúsculas/Minúsculas
        String texto = entrada.trim().toLowerCase();

        // 2. Usamos 'contains' en vez de 'equals' para buscar la palabra clave dentro de la frase
        if (texto.contains("nuevo")) {
            notificar(NuiCommand.NUEVO_DOCUMENTO, null);
        }
        else if (texto.contains("abrir")) {
            notificar(NuiCommand.ABRIR_DOCUMENTO, null);
        }
        else if (texto.contains("guardar")) {
            notificar(NuiCommand.GUARDAR_DOCUMENTO, null);
        }
        else if (texto.contains("negrita")) { // Detectará "ponlo en negrita por favor"
            notificar(NuiCommand.APLICAR_NEGRITA, null);
        }
        else if (texto.contains("cursiva")) {
            notificar(NuiCommand.APLICAR_CURSIVA, null);
        }
        else if (texto.contains("rojo")) {
            notificar(NuiCommand.COLOR_ROJO, null);
        }
        else if (texto.contains("azul")) {
            notificar(NuiCommand.COLOR_AZUL, null);
        }
    }

    private void notificar(NuiCommand cmd, String payload) {
        for (NuiListener l : listeners) {
            l.onCommand(cmd, payload);
        }
    }
}
