package com.example.editortextogui;

public class TextUtils {

    public static String toUpper(String text){
        return text.toUpperCase();
    }

    public static String invert(String text){
        return new StringBuilder(text).reverse().toString();
    }

    public static String removeDoubleSpaces(String text){
        return text.replaceAll("\\s+", " ");
    }
}

