package com.example.editortextogui;


public enum NuiCommand {
    NUEVO_DOCUMENTO,
    ABRIR_DOCUMENTO,
    GUARDAR_DOCUMENTO,
    APLICAR_NEGRITA,
    APLICAR_CURSIVA,
    COLOR_ROJO,
    COLOR_AZUL
}

